# forms-constants

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build forms-constants` to build the library.
