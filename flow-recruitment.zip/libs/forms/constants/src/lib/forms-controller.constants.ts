const ENDPOINT_FORMS_SLUG = 'forms';

export { ENDPOINT_FORMS_SLUG };
