import { FormResponseAnswer } from '@flow-recruitment/prisma/client';

type UpdateFormResponseAnswerValueResult = FormResponseAnswer;

export type { UpdateFormResponseAnswerValueResult };
