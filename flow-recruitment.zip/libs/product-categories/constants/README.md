# product-categories-constants

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build product-categories-constants` to build the library.
