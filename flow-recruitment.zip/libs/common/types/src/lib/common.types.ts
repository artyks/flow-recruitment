type WithUserId = { userId: string };

export type { WithUserId };
