# common-types

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build common-types` to build the library.
