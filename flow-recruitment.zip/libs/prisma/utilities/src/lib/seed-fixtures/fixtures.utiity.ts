const YesNoOptions = ['Yes', 'No'];

export { YesNoOptions };
