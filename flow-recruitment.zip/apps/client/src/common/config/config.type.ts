type Config = {
  BE_SERVER: {
    PROTOCOL: string;
    PORT: number;
    HOST: string;
    GLOBAL_PREFIX: string;
  };
};

export type { Config };
